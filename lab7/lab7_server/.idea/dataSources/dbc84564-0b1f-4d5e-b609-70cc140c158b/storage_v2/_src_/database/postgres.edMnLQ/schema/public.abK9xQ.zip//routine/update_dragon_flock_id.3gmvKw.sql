create function update_dragon_flock_id() returns trigger
    language plpgsql
as
$$
begin
    update dragon
    set flock_id = new.id
    where new.leader_id = id;
    return new;
end;
$$;

alter function update_dragon_flock_id() owner to s264484;

