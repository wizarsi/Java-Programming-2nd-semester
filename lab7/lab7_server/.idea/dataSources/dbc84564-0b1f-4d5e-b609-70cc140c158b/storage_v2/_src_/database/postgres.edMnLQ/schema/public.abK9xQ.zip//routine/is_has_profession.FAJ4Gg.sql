create function is_has_profession(integer, character varying) returns boolean
    language plpgsql
as
$$
begin
    return exists(select * from citizen_profession
                                    join profession on citizen_profession.profession_id = profession.id
                  WHERE profession.name LIKE $2 and citizen_profession.citizen_id = $1
        );
end;
$$;

alter function is_has_profession(integer, varchar) owner to s264484;

