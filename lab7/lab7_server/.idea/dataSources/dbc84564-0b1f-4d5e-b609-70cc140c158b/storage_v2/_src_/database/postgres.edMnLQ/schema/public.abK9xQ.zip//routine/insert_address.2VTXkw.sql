create function insert_address(entity_count integer, city character varying[], street character varying[]) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    random_city_idx integer := 0;
    random_street_idx integer := 0;
    random_building integer := 0;
begin
    for i in 1..entity_count loop
        random_city_idx := (random() * (array_length(city, 1) - 1) + 1)::integer;
        random_street_idx := (random() * (array_length(street, 1) - 1) + 1)::integer;
        random_building := (random() * (150 - 1) + 1)::integer;
       insert into address(owner_id, country, city, street, building, comment)
       values (i, 'Russian Federation', city[random_city_idx], street[random_street_idx], random_building, '');
    end loop;

END
$$;

alter function insert_address(integer, character varying[], character varying[]) owner to s264429;

