create function update_idea() returns trigger
    language plpgsql
as
$$
begin
    if (tg_op = 'INSERT') then
        perform update_idea_in_city(new.city_id);
        return new;
    elsif (tg_op = 'UPDATE') then
        ---если поменяли город
        if (new.city_id <> old.city_id) then
            perform update_idea_in_city(new.city_id);
            perform update_idea_in_city(old.city_id);
            ---если меняется дата или идея
        elsif (new.date <> old.date or new.idea <> old.idea) then
            perform update_idea_in_city(new.city_id);
        end if;
        return new;
    elsif (tg_op = 'DELETE') then
        perform update_idea_in_city(old.city_id);
        return old;
    end if;
end;
$$;

alter function update_idea() owner to s264484;

