create function check_storage() returns trigger
    language plpgsql
as
$$
begin
            if ((select count(id) from Материал where NEW.Склад_id = Склад_id) <= (select Объем_склада from Склад where NEW.Склад_id = id)) then
                raise exception 'Данный склад переполнен';
            end if;
            return null;
        end;
$$;

alter function check_storage() owner to s263232;

