create function insert_store_item() returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    product_id integer := 0;
    store_id integer := 0;
    stores_count integer := 0;
    products_count integer := 0;
begin
    select count(*) from store into stores_count;
    select count(*) from product into products_count;

    for i in 1..stores_count loop
        select id from product order by random() limit 1 into product_id;
        insert into store_item values (i, product_id, random() * 190 + 10) on conflict do nothing;
    end loop;

    for i in 1..products_count loop
        select id from store order by random() limit 1 into store_id;
        insert into store_item values (store_id, i, random() * 190 + 10) on conflict do nothing;
    end loop;

end;
$$;

alter function insert_store_item() owner to s264429;

