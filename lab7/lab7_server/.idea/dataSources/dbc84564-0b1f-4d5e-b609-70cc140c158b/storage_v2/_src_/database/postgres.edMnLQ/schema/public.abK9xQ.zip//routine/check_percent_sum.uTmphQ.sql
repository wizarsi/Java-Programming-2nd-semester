create function check_percent_sum() returns trigger
    language plpgsql
as
$$
declare
    percent_sum integer;
begin
    perform *
    from citizen
             inner join city on city_id = city.id
    where citizen.id = new.candidate_id
      and land_id = new.land_id;
    if not FOUND then
        raise exception 'Кандидат - чужеземец';
    end if;

    select sum(votes_percent)
    into percent_sum
    from election
    where election.date = new.date
      and election.land_id = new.land_id;
    percent_sum = percent_sum + new.votes_percent;
    if (percent_sum > 100) then
        raise exception 'Сумма процентов всех голосов в выборах больше ста';
    end if;
    return new;
end;
$$;

alter function check_percent_sum() owner to s264484;

