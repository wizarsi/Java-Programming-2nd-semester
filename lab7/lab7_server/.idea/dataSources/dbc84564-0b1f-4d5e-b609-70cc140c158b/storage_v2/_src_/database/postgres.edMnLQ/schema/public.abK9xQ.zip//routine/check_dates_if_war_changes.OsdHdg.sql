create function check_dates_if_war_changes() returns trigger
    language plpgsql
as
$$
declare
    war_start_date     date;
    war_finish_date    date;
    battle_start_date  date;
    battle_finish_date date;
    index              integer;
begin
    war_start_date = new.start_date;
    war_finish_date = new.finish_date;
    for index in
        --проверяем по всем битвам в этой войне
        select id from battle where war_id = new.id
        loop
            select start_date into battle_start_date from battle where id = index;
            select finish_date into battle_finish_date from war where id = index;
            if (war_start_date > battle_start_date) then
                raise exception 'Начало битвы % не может быть раньше начала войны', index;
            end if;
            if (war_finish_date < battle_finish_date) then
                raise exception 'Война не может закончиться раньше битвы %', index;
            end if;
        end loop;
    return new;
end;
$$;

alter function check_dates_if_war_changes() owner to s264484;

