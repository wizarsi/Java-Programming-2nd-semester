create function insert_circuit_board_model(ids character varying[], versions character varying[]) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    j integer := 0;
begin
    for i in 1..array_length(ids, 1) loop
        for j in 1..array_length(versions, 1) loop
                    insert into circuit_board_model values (ids[i], versions[j], (random()+0.1)::real,
                                                            (random() * 10 + 10)::real, (random() * 20 + 10)::real, (random()*90 + 25)::real);
        end loop;
    end loop;
end;
$$;

alter function insert_circuit_board_model(character varying[], character varying[]) owner to s264429;

