create function delete_null_row() returns trigger
    language plpgsql
as
$$
begin
    if (new.combat_dragon_id is null and new.soldier_id is null) then
        delete from combat_unit where new.id = combat_unit.id;
    end if;
    return new;
end;
$$;

alter function delete_null_row() owner to s264484;

