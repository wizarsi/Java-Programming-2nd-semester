create function get_citizen_of_dragon(integer) returns integer
    language plpgsql
as
$$
begin
    return (select citizen.id from citizen where  citizen.dragon_id = $1);
end;
$$;

alter function get_citizen_of_dragon(integer) owner to s264484;

